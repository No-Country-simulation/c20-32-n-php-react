// components/Page1.js
import React from 'react';

function Page4() {
    return (
        <div>
            <h1>page 4</h1>
            <div><a href="/">link 1</a></div>
            <div><a href="/Page3">link 3</a></div>
            <div><a href="/Page2">link 2</a></div>
             
        </div>
    );
}

export default Page4;