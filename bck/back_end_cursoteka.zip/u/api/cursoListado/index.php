<?php

include '../../controller/cursoListadoControler.php';
?>