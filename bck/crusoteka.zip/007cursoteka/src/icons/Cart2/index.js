export { Cart2 } from "./Cart2";
