<?php

include '../../controller/curso_recursosController.php';
?>