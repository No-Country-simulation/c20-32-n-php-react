export { Search2 } from "./Search2";
