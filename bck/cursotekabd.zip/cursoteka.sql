-- --------------------------------------------------------
-- Host:                         192.168.1.10
-- Server version:               8.0.39-0ubuntu0.20.04.1 - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for cursoteka
DROP DATABASE IF EXISTS `cursoteka`;
CREATE DATABASE IF NOT EXISTS `cursoteka` /*!40100 DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `cursoteka`;

-- Dumping structure for table cursoteka.curso
CREATE TABLE IF NOT EXISTS `curso` (
  `id_curso` bigint NOT NULL AUTO_INCREMENT,
  `titulo` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `contenido` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `duracion` int DEFAULT NULL,
  `foto` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `valoracion` int DEFAULT NULL,
  `costo` float DEFAULT NULL,
  `id_instructor` bigint DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_reg` bigint DEFAULT NULL,
  `fecha_mod` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `id_user_mod` bigint DEFAULT NULL,
  PRIMARY KEY (`id_curso`),
  KEY `fk_instructor` (`id_instructor`),
  CONSTRAINT `fk_instructor` FOREIGN KEY (`id_instructor`) REFERENCES `usuario` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table cursoteka.curso: ~6 rows (approximately)
INSERT INTO `curso` (`id_curso`, `titulo`, `descripcion`, `contenido`, `duracion`, `foto`, `valoracion`, `costo`, `id_instructor`, `fecha_registro`, `id_usuario_reg`, `fecha_mod`, `id_user_mod`) VALUES
	(17, 'Curso de Programación en Python', 'Un curso completo para aprender Python desde cero.', 'Contenido detallado sobre Python', 30, 'foto_python.jpg', 5, 99.99, 26, '2024-08-27 15:41:20', 26, NULL, NULL),
	(18, 'Curso de Programación en Python', 'Un curso completo para aprender Python desde cero.', 'Contenido detallado sobre Python.', 30, 'foto_python.jpg', 5, 99.99, 27, '2024-08-27 15:42:21', 27, NULL, NULL),
	(19, 'Introducción al Desarrollo Web', 'Curso básico de desarrollo web con HTML, CSS y JavaScript.', 'Material introductorio y ejemplos prácticos.', 20, 'foto_web.jpg', 4, 49.99, 27, '2024-08-27 15:42:21', 27, NULL, NULL),
	(20, 'Diseño Gráfico con Photoshop', 'Aprende a usar Photoshop para crear diseños impactantes.', 'Tutoriales paso a paso sobre Photoshop.', 25, 'foto_photoshop.jpg', 4, 79.99, 27, '2024-08-27 15:42:21', 26, NULL, NULL),
	(21, 'Análisis de Datos con R', 'Curso avanzado sobre análisis de datos utilizando R.', 'Contenido especializado en análisis estadístico.', 40, 'foto_r.jpg', 5, 149.99, 27, '2024-08-27 15:42:21', 26, NULL, NULL),
	(22, 'Manejo de Bases de Datos con MySQL', 'Curso práctico para aprender a manejar bases de datos con MySQL.', 'Material exhaustivo sobre administración de bases de datos.', 35, 'foto_mysql.jpg', 4, 89.99, 30, '2024-08-27 15:42:21', 26, NULL, NULL),
	(23, 'Curso 1', 'Descripción del curso 1', 'Contenido del curso 1', 60, 'foto1.jpg', 5, 49.99, 29, '2024-09-14 19:20:16', 1, NULL, NULL),
	(24, 'Curso 2', 'Descripción del curso 2', 'Contenido del curso 2', 90, 'foto2.jpg', 4, 59.99, 30, '2024-09-14 19:20:16', 2, NULL, NULL),
	(25, 'Curso 3', 'Descripción del curso 3', 'Contenido del curso 3', 120, 'foto3.jpg', 3, 69.99, 31, '2024-09-14 19:20:16', 3, NULL, NULL),
	(26, 'Curso 4', 'Descripción del curso 4', 'Contenido del curso 4', 180, 'foto4.jpg', 5, 79.99, 32, '2024-09-14 19:20:16', 4, NULL, NULL),
	(27, 'Curso 5', 'Descripción del curso 5', 'Contenido del curso 5', 240, 'foto5.jpg', 4, 89.99, 33, '2024-09-14 19:20:16', 5, NULL, NULL),
	(28, 'Curso 6', 'Descripción del curso 6', 'Contenido del curso 6', 60, 'foto6.jpg', 5, 49.99, 66, '2024-09-14 19:20:16', 6, NULL, NULL),
	(29, 'Curso 7', 'Descripción del curso 7', 'Contenido del curso 7', 90, 'foto7.jpg', 4, 59.99, 70, '2024-09-14 19:20:16', 7, NULL, NULL),
	(30, 'Curso 8', 'Descripción del curso 8', 'Contenido del curso 8', 120, 'foto8.jpg', 3, 69.99, 83, '2024-09-14 19:20:16', 8, NULL, NULL),
	(31, 'Curso 9', 'Descripción del curso 9', 'Contenido del curso 9', 180, 'foto9.jpg', 5, 79.99, 84, '2024-09-14 19:20:16', 9, NULL, NULL),
	(32, 'Curso 10', 'Descripción del curso 10', 'Contenido del curso 10', 240, 'foto10.jpg', 4, 89.99, 85, '2024-09-14 19:20:16', 10, NULL, NULL),
	(33, 'Curso 11', 'Descripción del curso 11', 'Contenido del curso 11', 60, 'foto11.jpg', 5, 49.99, 88, '2024-09-14 19:20:16', 11, NULL, NULL),
	(34, 'Curso 12', 'Descripción del curso 12', 'Contenido del curso 12', 90, 'foto12.jpg', 4, 59.99, 90, '2024-09-14 19:20:16', 12, NULL, NULL),
	(35, 'Curso 13', 'Descripción del curso 13', 'Contenido del curso 13', 120, 'foto13.jpg', 3, 69.99, 91, '2024-09-14 19:20:16', 13, NULL, NULL),
	(36, 'Curso 14', 'Descripción del curso 14', 'Contenido del curso 14', 180, 'foto14.jpg', 5, 79.99, 94, '2024-09-14 19:20:16', 14, NULL, NULL),
	(37, 'Curso 15', 'Descripción del curso 15', 'Contenido del curso 15', 240, 'foto15.jpg', 4, 89.99, 95, '2024-09-14 19:20:16', 15, NULL, NULL),
	(38, 'Curso 16', 'Descripción del curso 16', 'Contenido del curso 16', 60, 'foto16.jpg', 5, 49.99, 97, '2024-09-14 19:20:16', 16, NULL, NULL),
	(39, 'Curso 17', 'Descripción del curso 17', 'Contenido del curso 17', 90, 'foto17.jpg', 4, 59.99, 98, '2024-09-14 19:20:16', 17, NULL, NULL),
	(40, 'Curso 18', 'Descripción del curso 18', 'Contenido del curso 18', 120, 'foto18.jpg', 3, 69.99, 102, '2024-09-14 19:20:16', 18, NULL, NULL),
	(41, 'Curso 19', 'Descripción del curso 19', 'Contenido del curso 19', 180, 'foto19.jpg', 5, 79.99, 103, '2024-09-14 19:20:16', 19, NULL, NULL),
	(42, 'Curso 20', 'Descripción del curso 20', 'Contenido del curso 20', 240, 'foto20.jpg', 4, 89.99, 112, '2024-09-14 19:20:16', 20, NULL, NULL),
	(43, 'Curso 21', 'Descripción del curso 21', 'Contenido del curso 21', 60, 'foto21.jpg', 5, 49.99, 115, '2024-09-14 19:20:16', 21, NULL, NULL),
	(44, 'Curso 22', 'Descripción del curso 22', 'Contenido del curso 22', 90, 'foto22.jpg', 4, 59.99, 29, '2024-09-14 19:20:16', 22, NULL, NULL),
	(45, 'Curso 23', 'Descripción del curso 23', 'Contenido del curso 23', 120, 'foto23.jpg', 3, 69.99, 30, '2024-09-14 19:20:16', 23, NULL, NULL),
	(46, 'Curso 24', 'Descripción del curso 24', 'Contenido del curso 24', 180, 'foto24.jpg', 5, 79.99, 31, '2024-09-14 19:20:16', 24, NULL, NULL),
	(47, 'Curso 25', 'Descripción del curso 25', 'Contenido del curso 25', 240, 'foto25.jpg', 4, 89.99, 32, '2024-09-14 19:20:16', 25, NULL, NULL),
	(48, 'Curso 26', 'Descripción del curso 26', 'Contenido del curso 26', 60, 'foto26.jpg', 5, 49.99, 33, '2024-09-14 19:20:16', 26, NULL, NULL),
	(49, 'Curso 27', 'Descripción del curso 27', 'Contenido del curso 27', 90, 'foto27.jpg', 4, 59.99, 66, '2024-09-14 19:20:16', 27, NULL, NULL),
	(50, 'Curso 28', 'Descripción del curso 28', 'Contenido del curso 28', 120, 'foto28.jpg', 3, 69.99, 70, '2024-09-14 19:20:16', 28, NULL, NULL),
	(51, 'Curso 29', 'Descripción del curso 29', 'Contenido del curso 29', 180, 'foto29.jpg', 5, 79.99, 83, '2024-09-14 19:20:16', 29, NULL, NULL);

-- Dumping structure for table cursoteka.curso_recursos
CREATE TABLE IF NOT EXISTS `curso_recursos` (
  `id_curso_recurso` bigint NOT NULL AUTO_INCREMENT,
  `id_curso` bigint NOT NULL,
  `nombre` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `detalle_recurso` text CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci,
  `tipo_recurso` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `fecha_reg` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_mod` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `user_ad` bigint DEFAULT NULL,
  `user_mod` bigint DEFAULT NULL,
  PRIMARY KEY (`id_curso_recurso`),
  KEY `fk_curso_rec` (`id_curso`),
  CONSTRAINT `fk_curso_rec` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Dumping data for table cursoteka.curso_recursos: ~5 rows (approximately)
INSERT INTO `curso_recursos` (`id_curso_recurso`, `id_curso`, `nombre`, `detalle_recurso`, `tipo_recurso`, `fecha_reg`, `fecha_mod`, `user_ad`, `user_mod`) VALUES
	(6, 17, 'Introducción al curso', 'Recurso detallado para el curso 11', 'Video', '2024-08-28 15:53:23', '2024-09-14 18:35:55', 26, NULL),
	(7, 17, 'Guía del estudiante', 'Recurso adicional para el curso 12', 'Documento', '2024-08-28 15:53:23', '2024-09-14 18:36:41', 27, NULL),
	(8, 18, 'Diapositivas del módulo 1', 'Material de apoyo para el curso 13', 'Presentación', '2024-08-28 15:53:23', '2024-09-14 18:36:03', 28, NULL),
	(12, 17, 'bbb', 'material adciona recuros', 'quiz', '2024-09-14 22:25:21', '2024-09-14 22:34:40', 0, NULL),
	(13, 17, 'ccc', 'c', 'video', '2024-09-14 22:28:17', NULL, 0, NULL),
	(14, 17, 'ddd', 'd', 'Documento', '2024-09-14 22:29:28', NULL, 0, NULL),
	(15, 17, 'eee', 'e', 'Documento', '2024-09-14 22:30:51', NULL, 0, NULL),
	(16, 17, 'fff', 'f', 'video', '2024-09-14 22:32:11', NULL, 0, NULL),
	(17, 17, 'Recurso 1', 'Detalle del recurso 1', 'Video', '2024-09-14 22:37:20', NULL, 1, NULL),
	(18, 17, 'Recurso 2', 'Detalle del recurso 2', 'PDF', '2024-09-14 22:37:20', NULL, 1, NULL),
	(19, 17, 'Recurso 3', 'Detalle del recurso 3', 'Documento', '2024-09-14 22:37:20', NULL, 1, NULL),
	(20, 17, 'Recurso 4', 'Detalle del recurso 4', 'Audio', '2024-09-14 22:37:20', NULL, 2, NULL),
	(21, 17, 'Recurso 5', 'Detalle del recurso 5', 'Video', '2024-09-14 22:37:20', NULL, 2, NULL),
	(22, 17, 'Recurso 6', 'Detalle del recurso 6', 'PDF', '2024-09-14 22:37:20', NULL, 3, NULL),
	(23, 17, 'Recurso 7', 'Detalle del recurso 7', 'Documento', '2024-09-14 22:37:20', NULL, 3, NULL),
	(24, 17, 'Recurso 8', 'Detalle del recurso 8', 'Audio', '2024-09-14 22:37:20', NULL, 4, NULL),
	(25, 17, 'Recurso 9', 'Detalle del recurso 9', 'Video', '2024-09-14 22:37:20', NULL, 4, NULL),
	(26, 17, 'Recurso 10', 'Detalle del recurso 10', 'PDF', '2024-09-14 22:37:20', NULL, 5, NULL),
	(27, 17, 'Recurso 11', 'Detalle del recurso 11', 'Documento', '2024-09-14 22:37:20', NULL, 5, NULL),
	(28, 17, 'Recurso 12', 'Detalle del recurso 12', 'Audio', '2024-09-14 22:37:20', NULL, 6, NULL),
	(29, 17, 'Recurso 13', 'Detalle del recurso 13', 'Video', '2024-09-14 22:37:20', NULL, 6, NULL),
	(30, 17, 'Recurso 14', 'Detalle del recurso 14', 'PDF', '2024-09-14 22:37:20', NULL, 7, NULL),
	(31, 17, 'Recurso 15', 'Detalle del recurso 15', 'Documento', '2024-09-14 22:37:20', NULL, 7, NULL),
	(32, 17, 'Recurso 16', 'Detalle del recurso 16', 'Audio', '2024-09-14 22:37:20', NULL, 8, NULL),
	(33, 17, 'Recurso 17', 'Detalle del recurso 17', 'Video', '2024-09-14 22:37:20', NULL, 8, NULL),
	(34, 17, 'Recurso 18', 'Detalle del recurso 18', 'PDF', '2024-09-14 22:37:20', NULL, 9, NULL),
	(35, 17, 'Recurso 19', 'Detalle del recurso 19', 'Documento', '2024-09-14 22:37:20', NULL, 9, NULL),
	(36, 17, 'Recurso 20', 'Detalle del recurso 20', 'Audio', '2024-09-14 22:37:20', NULL, 10, NULL),
	(37, 17, 'Recurso 21', 'Detalle del recurso 21', 'Video', '2024-09-14 22:37:20', NULL, 10, NULL),
	(38, 17, 'Recurso 22', 'Detalle del recurso 22', 'PDF', '2024-09-14 22:37:20', NULL, 11, NULL),
	(39, 17, 'Recurso 23', 'Detalle del recurso 23', 'Documento', '2024-09-14 22:37:20', NULL, 11, NULL),
	(40, 17, 'Recurso 24', 'Detalle del recurso 24', 'Audio', '2024-09-14 22:37:20', NULL, 12, NULL),
	(41, 17, 'Recurso 25', 'Detalle del recurso 25', 'Video', '2024-09-14 22:37:20', NULL, 12, NULL),
	(42, 17, 'Recurso 26', 'Detalle del recurso 26', 'PDF', '2024-09-14 22:37:20', NULL, 13, NULL),
	(43, 17, 'Recurso 27', 'Detalle del recurso 27', 'Documento', '2024-09-14 22:37:20', NULL, 13, NULL),
	(44, 17, 'Recurso 28', 'Detalle del recurso 28', 'Audio', '2024-09-14 22:37:20', NULL, 14, NULL),
	(45, 17, 'Recurso 29', 'Detalle del recurso 29', 'Video', '2024-09-14 22:37:20', NULL, 14, NULL),
	(46, 17, 'Recurso 30 treinta', 'Detalle del recurso 30 xxx', 'video', '2024-09-14 22:37:20', '2024-09-14 23:05:10', 15, 0),
	(47, 17, 'rec1 uno', 'a gfgfdg', 'Quiz', '2024-09-14 23:07:30', '2024-09-14 23:07:41', 0, 0),
	(48, 17, 'erty mod', 'aaa bbb mod', 'Documento', '2024-09-14 23:11:27', '2024-09-14 23:11:41', 0, 0);

-- Dumping structure for table cursoteka.estudiante_curso
CREATE TABLE IF NOT EXISTS `estudiante_curso` (
  `id_curso_estudiante` bigint NOT NULL AUTO_INCREMENT,
  `id_estudiante` bigint NOT NULL,
  `id_curso` bigint NOT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo_pago` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `direccion_facturacion` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `id_user_add` bigint DEFAULT NULL,
  `fecha_mod` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `id_user_mod` bigint DEFAULT NULL,
  PRIMARY KEY (`id_curso_estudiante`),
  KEY `fk_estudiante` (`id_estudiante`),
  KEY `fk_curso` (`id_curso`),
  CONSTRAINT `fk_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id_curso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_estudiante` FOREIGN KEY (`id_estudiante`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci;

-- Dumping data for table cursoteka.estudiante_curso: ~5 rows (approximately)
INSERT INTO `estudiante_curso` (`id_curso_estudiante`, `id_estudiante`, `id_curso`, `fecha_registro`, `tipo_pago`, `direccion_facturacion`, `id_user_add`, `fecha_mod`, `id_user_mod`) VALUES
	(6, 26, 29, '2024-08-27 16:01:01', 'Tarjeta de Crédito', 'Calle Falsa 123', 26, NULL, NULL),
	(7, 27, 30, '2024-08-27 16:01:01', 'Transferencia Bancaria', 'Avenida Siempre Viva 742', 27, NULL, NULL),
	(8, 28, 31, '2024-08-27 16:01:01', 'PayPal', 'Plaza Mayor 456', 28, NULL, NULL),
	(9, 29, 32, '2024-08-27 16:01:01', 'Efectivo', 'Calle del Pez 89', 29, NULL, NULL),
	(10, 30, 33, '2024-08-27 16:01:01', 'Tarjeta de Débito', 'Calle Luna 321', 30, NULL, NULL);

-- Dumping structure for table cursoteka.persona
CREATE TABLE IF NOT EXISTS `persona` (
  `id_persona` bigint NOT NULL AUTO_INCREMENT,
  `nombres` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `paterno` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `materno` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `direccion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci,
  `telefono` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `mobile` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT (now()),
  `id_usuario_reg` bigint DEFAULT NULL,
  `fecha_mod` timestamp NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  `id_user_mod` bigint DEFAULT NULL,
  `id_profesion` bigint DEFAULT NULL,
  PRIMARY KEY (`id_persona`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table cursoteka.persona: ~49 rows (approximately)
INSERT INTO `persona` (`id_persona`, `nombres`, `paterno`, `materno`, `direccion`, `telefono`, `mobile`, `fecha_nacimiento`, `fecha_registro`, `id_usuario_reg`, `fecha_mod`, `id_user_mod`, `id_profesion`) VALUES
	(11, 'Juan', 'Pérez', '', 'Calle Falsa 123', '555-1234', NULL, '1990-04-23', '2024-08-27 13:52:32', 1, '2024-08-27 13:52:32', 1, 101),
	(12, 'María', 'Gómez', '', 'Av. Siempre Viva 456', '555-5678', NULL, '1985-09-15', '2024-08-27 13:52:32', 1, '2024-08-27 13:52:32', 2, 102),
	(13, 'Pedro', 'Martínez', 'merida', 'Plaza Mayor 789', '555-9876', NULL, '1978-12-02', '2024-08-27 13:52:32', 2, '2024-09-09 20:05:41', 2, 103),
	(14, 'Lucía', 'Rodríguez', '', 'Calle Luna 321', '555-4321', NULL, '1992-03-08', '2024-08-27 13:52:32', 3, '2024-08-27 13:52:32', 3, 104),
	(15, 'Carlos', 'Fernández', '', 'Av. Sol 654', '555-8765', NULL, '1980-06-30', '2024-08-27 13:52:32', 2, '2024-08-27 13:52:32', 4, 105),
	(16, 'favian', 'medina', '', 'Calle bartolome 123', '222-230740', '', '1973-01-20', '2024-09-05 22:16:44', 1, '2024-09-05 22:16:44', NULL, 101),
	(61, 'cedric', 'balboa', '', 'avenida harry potter', '12398755', '', '1988-06-08', '2024-09-09 17:09:14', NULL, '2024-09-10 23:37:35', 0, NULL),
	(62, 'Juan', 'Pérez', 'García', 'Calle Principal 123', '12345678', '987654321', '1990-01-01', '2024-09-09 21:43:14', 1, '2024-09-09 21:43:14', NULL, 1),
	(63, 'María', 'Rodríguez', 'López', 'Avenida Secundaria 456', '23456789', '876543210', '1995-02-02', '2024-09-09 21:43:14', 2, '2024-09-09 21:43:14', NULL, 2),
	(65, 'Juan', 'Pérez', 'García', 'Calle Principal 123', '12345678', '987654321', '1990-01-01', '2024-09-09 21:43:24', 1, '2024-09-09 21:43:24', NULL, 1),
	(66, 'María', 'Rodríguez', 'López', 'Avenida Secundaria 456', '23456789', '876543210', '1995-02-02', '2024-09-09 21:43:24', 2, '2024-09-09 21:43:24', NULL, 2),
	(67, 'Ana', 'Martínez', 'González', 'Calle Terciaria 789', '34567890', '765432109', '2000-03-03', '2024-09-09 21:43:24', 20, '2024-09-09 21:43:24', NULL, 20),
	(68, 'Juan1', 'Pérez', 'García', 'Calle Principal 123', '12345678', '987654321', '1990-01-01', '2024-09-09 21:45:38', 1, '2024-09-09 21:45:38', NULL, 1),
	(69, 'María1', 'Rodríguez', 'López', 'Avenida Secundaria 456', '23456789', '876543210', '1995-02-02', '2024-09-09 21:45:38', 2, '2024-09-09 21:45:38', NULL, 2),
	(70, 'Ana1', 'Martínez', 'González', 'Calle Terciaria 789', '34567890', '765432109', '2000-03-03', '2024-09-09 21:45:38', 20, '2024-09-09 21:45:38', NULL, 20),
	(71, 'Juan1', 'Pérez', 'García', 'Calle Principal 123', '12345678', '987654321', '1990-01-01', '2024-09-09 21:46:11', 1, '2024-09-09 21:46:11', NULL, 1),
	(72, 'María1', 'Rodríguez', 'López', 'Avenida Secundaria 456', '23456789', '876543210', '1995-02-02', '2024-09-09 21:46:11', 2, '2024-09-09 21:46:11', NULL, 2),
	(73, 'Ana1', 'Martínez', 'González', 'Calle Terciaria 789', '34567890', '765432109', '2000-03-03', '2024-09-09 21:46:11', 20, '2024-09-09 21:46:11', NULL, 20),
	(74, 'Juan', 'Pérez', 'González', 'Calle 123, Ciudad X', '555123456', '777654321', '1980-09-23', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 1),
	(75, 'María', 'Gómez', 'Martínez', 'Av. Principal, Ciudad Y', '555234567', '777123456', '1985-04-15', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 2),
	(76, 'Carlos', 'Sánchez', 'Rodríguez', 'Calle Falsa 456, Ciudad Z', '555345678', '777234567', '1990-12-01', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 3),
	(77, 'Ana', 'Fernández', 'Lopez', 'Av. Central 789, Ciudad A', '555456789', '777345678', '1982-06-12', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 1),
	(78, 'Luis', 'Hernández', 'Torres', 'Calle Nueva 101, Ciudad B', '555567890', '777456789', '1978-03-27', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 2),
	(79, 'Claudia', 'Ramírez', 'García', 'Barrio Sur, Ciudad C', '555678901', '777567890', '1995-11-18', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 3),
	(80, 'José', 'Rivera', 'Vargas', 'Zona Norte, Ciudad D', '555789012', '777678901', '1987-07-30', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 1),
	(81, 'Elena', 'Castro', 'Mendoza', 'Calle Larga 222, Ciudad E', '555890123', '777789012', '1992-01-05', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 2),
	(82, 'Miguel', 'Morales', 'Ramírez', 'Av. Los Pinos 303, Ciudad F', '555901234', '777890123', '1989-09-17', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 3),
	(83, 'Lucía', 'Vega', 'Silva', 'Plaza Central 404, Ciudad G', '555012345', '777901234', '1983-05-22', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 1),
	(84, 'Pedro', 'Rojas', 'Ortiz', 'Calle del Sol, Ciudad H', '555123567', '777012345', '1986-08-14', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 2),
	(85, 'Laura', 'Mendoza', 'Romero', 'Avenida del Mar, Ciudad I', '555234678', '777123567', '1991-02-28', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 3),
	(86, 'Fernando', 'Ortiz', 'Hidalgo', 'Zona Este, Ciudad J', '555345789', '777234678', '1979-10-09', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 1),
	(87, 'Sara', 'Luna', 'Aguilar', 'Calle Central, Ciudad K', '555456890', '777345789', '1984-07-06', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 2),
	(88, 'Ricardo', 'Navarro', 'Pérez', 'Calle Nueva, Ciudad L', '555567901', '777456890', '1996-03-25', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 3),
	(89, 'Patricia', 'Valenzuela', 'Moreno', 'Barrio Antiguo, Ciudad M', '555678012', '777567901', '1993-11-03', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 1),
	(90, 'Diego', 'Guerrero', 'Campos', 'Zona Sur, Ciudad N', '555789123', '777678012', '1988-12-22', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 2),
	(91, 'Isabel', 'Figueroa', 'Reyes', 'Plaza Mayor, Ciudad O', '555890234', '777789123', '1985-04-18', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 3),
	(92, 'Héctor', 'Ramos', 'Medina', 'Calle 404, Ciudad P', '555901345', '777890234', '1990-10-10', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 1),
	(93, 'Adriana', 'Blanco', 'Núñez', 'Zona Oeste, Ciudad Q', '555012456', '777901345', '1994-06-27', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 2),
	(94, 'Ramón', 'Domínguez', 'Cruz', 'Zona Centro, Ciudad R', '555123567', '777012456', '1981-02-05', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 3),
	(95, 'Carolina', 'Peña', 'Paredes', 'Av. Las Flores, Ciudad S', '555234678', '777123567', '1986-09-19', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 1),
	(96, 'Francisco', 'Quintero', 'Ruiz', 'Calle Principal, Ciudad T', '555345789', '777234678', '1977-11-24', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 2),
	(97, 'Sofía', 'Guzmán', 'Castillo', 'Calle del Centro, Ciudad U', '555456890', '777345789', '1989-03-08', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 3),
	(98, 'Gustavo', 'Díaz', 'Sosa', 'Barrio Norte, Ciudad V', '555567901', '777456890', '1995-07-13', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 1),
	(99, 'Verónica', 'Mejía', 'Vargas', 'Calle Lateral, Ciudad W', '555678012', '777567901', '1992-05-26', '2024-09-09 21:48:32', 2, '2024-09-09 21:48:32', NULL, 2),
	(100, 'Daniel', 'Paredes', 'Contreras', 'Plaza Vieja, Ciudad X', '555789123', '777678012', '1983-12-14', '2024-09-09 21:48:32', 3, '2024-09-09 21:48:32', NULL, 3),
	(101, 'Mónica', 'Salazar', 'Moya', 'Avenida de la Paz, Ciudad Y', '555890234', '777789123', '1990-04-01', '2024-09-09 21:48:32', 4, '2024-09-09 21:48:32', NULL, 1),
	(102, 'Javier', 'Carrillo', 'Cabrera', 'Zona Verde, Ciudad Z', '555901345', '777890234', '1988-09-27', '2024-09-09 21:48:32', 1, '2024-09-09 21:48:32', NULL, 2),
	(121, 'juan', 'carrillo', '', 'calle falsa numero imaginario', '555-123456', '666-987654', '1982-01-14', '2024-09-10 21:30:13', 0, '2024-09-10 21:30:13', NULL, NULL),
	(123, 'janito', 'carreño', '', '', '', '', '2020-06-26', '2024-09-10 22:03:57', 0, '2024-09-10 22:47:34', 0, NULL);

-- Dumping structure for table cursoteka.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` bigint NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `email` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `password` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `fecha_registro` timestamp NULL DEFAULT (now()),
  `id_persona` bigint DEFAULT NULL,
  `id_usuario_reg` bigint DEFAULT NULL,
  `fecha_mod` timestamp NULL DEFAULT NULL,
  `id_user_mod` bigint DEFAULT NULL,
  `rol` enum('estudiante','instructor','administrador') CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT 'estudiante',
  PRIMARY KEY (`id_usuario`) USING BTREE,
  KEY `id_persona` (`id_persona`) USING BTREE,
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id_persona`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Dumping data for table cursoteka.usuario: ~22 rows (approximately)
INSERT INTO `usuario` (`id_usuario`, `nombre_usuario`, `email`, `password`, `fecha_registro`, `id_persona`, `id_usuario_reg`, `fecha_mod`, `id_user_mod`, `rol`) VALUES
	(29, 'juanperez', 'juanperez@example.com', 'password123', '2024-08-27 14:20:08', 11, NULL, NULL, NULL, 'estudiante'),
	(30, 'mariagomez', 'mariagomez@example.com', 'password456', '2024-08-27 14:20:08', 12, NULL, NULL, NULL, 'instructor'),
	(31, 'pedromartinez', 'pedromartinez@example.com', 'password789', '2024-08-27 14:20:08', 13, NULL, NULL, NULL, 'estudiante'),
	(32, 'luciarodriguez', 'luciarodriguez@example.com', 'password123', '2024-08-27 14:20:08', 14, NULL, NULL, NULL, 'estudiante'),
	(33, 'cf', 'carlosfernandez@example.com', '1', '2024-08-27 14:20:08', 15, NULL, NULL, NULL, 'administrador'),
	(66, 'uu1', 'cf22@example1.com', 'A1a', '2024-09-11 20:15:21', 12, NULL, NULL, 0, 'estudiante'),
	(70, 'user1', 'b@a.i', 'A1a', '2024-09-12 19:54:31', 11, 0, NULL, 0, 'instructor'),
	(83, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:06', 96, 0, NULL, NULL, 'estudiante'),
	(84, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:10', 102, 0, NULL, NULL, 'estudiante'),
	(85, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:11', 91, 0, NULL, NULL, 'estudiante'),
	(88, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:17', 63, 0, NULL, NULL, 'estudiante'),
	(90, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:21', 81, 0, NULL, NULL, 'estudiante'),
	(91, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:22', 76, 0, NULL, NULL, 'estudiante'),
	(94, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:28', 93, 0, NULL, NULL, 'estudiante'),
	(95, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:04:29', 94, 0, NULL, NULL, 'estudiante'),
	(97, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:05:17', 99, 0, NULL, NULL, 'estudiante'),
	(98, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:05:17', 74, 0, NULL, NULL, 'estudiante'),
	(102, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:05:25', 67, 0, NULL, NULL, 'estudiante'),
	(103, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:05:25', 74, 0, NULL, NULL, 'estudiante'),
	(112, 'usuario1', 'usuario1@email.com', 'password1', '2024-09-12 20:05:40', 85, 0, NULL, NULL, 'estudiante'),
	(115, 'nail1', 'a@a.i', 'A1a', '2024-09-12 20:19:39', 12, 0, NULL, NULL, 'instructor');

-- Dumping structure for view cursoteka.v_curso_listado
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `v_curso_listado` (
	`id_curso` BIGINT(19) NOT NULL,
	`titulos` TEXT NULL COLLATE 'utf8mb4_spanish_ci',
	`descripcion` VARCHAR(18) NULL COLLATE 'utf8mb4_spanish_ci',
	`duracion` INT(10) NULL,
	`costo` FLOAT NULL,
	`recursos` BIGINT(19) NOT NULL
) ENGINE=MyISAM;

-- Dumping structure for view cursoteka.v_usario_persona
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `v_usario_persona` (
	`id_usuario` BIGINT(19) NOT NULL,
	`nombre_usuario` VARCHAR(250) NOT NULL COLLATE 'utf8mb4_spanish_ci',
	`email` VARCHAR(250) NOT NULL COLLATE 'utf8mb4_spanish_ci',
	`rol` ENUM('estudiante','instructor','administrador') NOT NULL COLLATE 'utf8mb4_spanish_ci',
	`nombres` VARCHAR(242) NULL COLLATE 'utf8mb4_spanish_ci',
	`id_persona` BIGINT(19) NOT NULL,
	`password` VARCHAR(250) NOT NULL COLLATE 'utf8mb4_spanish_ci'
) ENGINE=MyISAM;

-- Dumping structure for view cursoteka.v_curso_listado
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `v_curso_listado`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_curso_listado` AS select `c`.`id_curso` AS `id_curso`,group_concat(distinct `c`.`titulo` separator ', ') AS `titulos`,concat(substr(`c`.`descripcion`,1,15),'...') AS `descripcion`,max(`c`.`duracion`) AS `duracion`,max(`c`.`costo`) AS `costo`,count(distinct `r`.`id_curso_recurso`) AS `recursos` from (`curso` `c` left join `curso_recursos` `r` on((`r`.`id_curso` = `c`.`id_curso`))) group by `c`.`id_curso`;

-- Dumping structure for view cursoteka.v_usario_persona
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `v_usario_persona`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_usario_persona` AS select `u`.`id_usuario` AS `id_usuario`,`u`.`nombre_usuario` AS `nombre_usuario`,`u`.`email` AS `email`,`u`.`rol` AS `rol`,concat(`p`.`nombres`,' ',`p`.`paterno`,' ',ifnull(`p`.`materno`,'')) AS `nombres`,`p`.`id_persona` AS `id_persona`,`u`.`password` AS `password` from (`persona` `p` join `usuario` `u` on((`p`.`id_persona` = `u`.`id_persona`)));

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
