<?php

include '../../controller/cursoController.php';
?>