// components/Page2.js
import React from 'react';

function Page3() {
    return (
        <div>
            <h1>pagina 3</h1>
            <div><a href="/Page2">link 2</a></div>
            <div><a href="/">link 1</a></div>
            <div><a href="/Page4">link 4</a></div>
        </div>
    );
}

export default Page3;