// components/Page2.js
import React from 'react';

function Page2() {
    return (
        <div>
            <h1>pagina 2</h1>
            <div><a href="/">link 1</a></div>
            <div><a href="/Page3">link 3</a></div>
            <div><a href="/Page4">link 4</a></div>
        </div>
    );
}

export default Page2;