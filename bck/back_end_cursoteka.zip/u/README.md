# API restfull Persona 
API en <b> PHP 8.0.30 </b> sin usar framework

Base de datos en <b>mysql 8.0.39</b>

Nombre de la base de datos: <b>cursoteka</b>
 

Paso 1: Clonar o descargar el proyecto en el directorio de tu servidor web

Paso 2: Crear/Importar una base de datos mysql usando scrip cursoteka.sql

Paso 3: Modificar los parametros de conexxion en el archivo ./config/db.php a la bd y colocar host, usuario, contraseña y nombre de la B.D, etc.

Paso 4: Visualizar en tu servidor la API, (http://localhost/c20-32-n-php-react/back-end/) o el host virutal asignado

Paso 5: actualizar el archivo .htaccess con la ruta correspondiente ej. en persona deberia contener lo siguiente

RewriteBase /c20-32-n-php-react/back-end/api/persona/

(C) 2024 

Damián Esteves

Favian Medina

Jhonatan Remon

Jeyson Olmos

Eleonora Ongaro

Diego Alberto Urioste

 
