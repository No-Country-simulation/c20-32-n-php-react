// App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import Principal from './components/01principal';
import Principal_Configuracion from './components/00principal_conf';
import Page2 from './components/page2'; 
import Page3 from './components/page3'; 
import Page4 from './components/page4';
import Student from './components/student';
import LoginSignup from './components/LoginSignup';
import LoginSignupAdmin from './components/LoginSignupAdm';
import Page014 from './components/page014';
import Persona from './components/persona';
import Usuario from './components/usuario';

 

function App() {
    return (
    <div className="App">
      <ToastContainer theme='colored' position='top-center'></ToastContainer>
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<Principal />} />
                <Route path="/page2" element={<Page2 />} />
                <Route path="/page4" element={<Page4 />} />
                <Route path="/Page3" element={<Page3 />} />
                <Route path="/Student" element={<Student />} />
                <Route path="/LoginSignup" element={<LoginSignup />} />
                <Route path="/Principal_Configuracion" element={<Principal_Configuracion />} />
                <Route path="/Page014" element={<Page014 />} />
                <Route path="/LoginSignupAdmin" element={<LoginSignupAdmin />} />
                <Route path="/Persona" element={<Persona />} />
                <Route path="/Usuario" element={<Usuario />} />
            </Routes>
        </BrowserRouter>
        </div>
    );
}

export default App;